<?php
include '../includes/db.php';

// Membuat direktori untuk menyimpan gambar jika belum ada
$uploadDir = __DIR__ . '/../uploads/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true); // Izin 0777 agar bisa menulis file
}

// Proses registrasi user
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $nik_ktp = $_POST['nik_ktp'];
    $no_sim = $_POST['no_sim'];
    $role = 'user'; // Role fixed untuk user

    // Validasi input
    if (empty($username) || empty($email) || empty($password) || empty($nik_ktp) || empty($no_sim) || empty($_FILES['ktp_image'])) {
        echo "Semua field harus diisi, termasuk file foto KTP.";
    } else {
        // Cek apakah email sudah digunakan
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $existing_user = $stmt->fetch();

        if ($existing_user) {
            echo "Email sudah terdaftar. Silakan gunakan email lain.";
        } else {
            // Proses upload file KTP
            $fileTmp = $_FILES['ktp_image']['tmp_name'];
            $fileName = basename($_FILES['ktp_image']['name']);
            $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
            $allowedExt = ['jpg', 'jpeg', 'png'];

            // Validasi tipe file
            if (!in_array($fileExt, $allowedExt)) {
                echo "Format file tidak diizinkan. Hanya JPG, JPEG, dan PNG.";
                exit();
            }

            // Nama file unik
            $newFileName = 'KTP_' . time() . '_' . uniqid() . '.' . $fileExt;
            $filePath = $uploadDir . $newFileName;

            // Pindahkan file ke direktori upload
            if (move_uploaded_file($fileTmp, $filePath)) {
                // Hash password
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                // Query untuk menambahkan data user
                $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role, nik_ktp, no_sim, ktp_image) VALUES (?, ?, ?, ?, ?, ?, ?)");
                if ($stmt->execute([$username, $email, $hashed_password, $role, $nik_ktp, $no_sim, 'uploads/' . $newFileName])) {
                    echo "User baru berhasil didaftarkan.";
                    header("Location: login.php"); // Redirect ke login setelah sukses
                    exit();
                } else {
                    echo "Terjadi kesalahan saat mendaftar.";
                }
            } else {
                echo "Gagal mengunggah file foto KTP.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi Pengguna</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            margin-top: 50px;
            color: #333;
        }

        .container {
            width: 50%;
            margin: 0 auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #333;
        }

        input[type="text"], input[type="email"], input[type="password"], input[type="file"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        p {
            text-align: center;
            color: #555;
        }

        a {
            color: #007bff;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        .error {
            color: red;
            text-align: center;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Registrasi Pengguna</h2>

        <!-- Menampilkan pesan error jika login gagal -->
        <?php if (isset($error_message)): ?>
            <p class="error"><?= htmlspecialchars($error_message); ?></p>
        <?php endif; ?>

        <form action="register.php" method="POST" enctype="multipart/form-data">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required>

            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>

            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>

            <label for="nik_ktp">NIK KTP</label>
            <input type="text" id="nik_ktp" name="nik_ktp" required>

            <label for="no_sim">Nomor SIM</label>
            <input type="text" id="no_sim" name="no_sim" required>

            <label for="ktp_image">Unggah Foto KTP</label>
            <input type="file" id="ktp_image" name="ktp_image" accept=".jpg, .jpeg, .png" required>

            <button type="submit">Daftar Pengguna</button>
        </form>

        <p>Sudah punya akun? <a href="login.php">Login di sini</a></p>
    </div>

</body>
</html>
