<?php
session_start();
include '../includes/db.php';

// Cek jika sudah login, langsung arahkan ke halaman utama
if (isset($_SESSION['user_id'])) {
    // Jika sudah login, cek role dan arahkan sesuai dengan role
    if ($_SESSION['role'] == 'admin') {
        header("Location: ../admin/dashboard.php");  // Halaman admin
    } else {
        header("Location: ../sewa_pernikahan.php");  // Halaman utama user
    }
    exit();
}

// Proses login jika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Ambil data user berdasarkan username
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    // Verifikasi password
    if ($user && password_verify($password, $user['password'])) {
        // Simpan data user ke session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];  // Menyimpan role user (admin/user)

        // Arahkan berdasarkan role (admin atau user)
        if ($user['role'] == 'admin') {
            header("Location: ../admin/index.php");  // Halaman khusus admin
        } else {
            header("Location: ../sewa_pernikahan.php");  // Halaman utama user
        }
        exit();
    } else {
        // Jika login gagal, tampilkan pesan error
        $error_message = "Username atau password salah.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        /* Global Styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7f6;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 30px;
            width: 400px;
            text-align: center;
        }

        h2 {
            margin-bottom: 20px;
            font-size: 24px;
            color: #333;
        }

        .error-message {
            color: red;
            margin-bottom: 15px;
            font-size: 14px;
        }

        form input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }

        form button {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        form button:hover {
            background-color: #4CAF50;
        }

        p {
            font-size: 14px;
        }

        p a {
            color: #007BFF;
            text-decoration: none;
        }

        p a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <!-- Login Container -->
    <div class="container">
        <h2>Login</h2>

        <!-- Menampilkan pesan error jika login gagal -->
        <?php if (isset($error_message)): ?>
            <p class="error-message"><?= htmlspecialchars($error_message); ?></p>
        <?php endif; ?>

        <!-- Form Login -->
        <form action="login.php" method="POST">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required><br>

            <label for="password">Password</label>
            <input type="password" id="password" name="password" required><br>

            <button type="submit">Login</button>
        </form>

        <p>Belum punya akun? <a href="register_user.php">Daftar di sini</a></p>
    </div>
</body>
</html>
