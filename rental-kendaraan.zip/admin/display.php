<?php
include '../includes/db.php';

// Ambil semua data pengguna
$stmt = $pdo->query("SELECT username, email, nik_ktp, no_sim, ktp_image FROM users");

// Periksa apakah ada data pengguna
if ($stmt->rowCount() > 0) {
    while ($row = $stmt->fetch()) {
        // Tampilkan informasi pengguna
        echo "<div style='border: 1px solid #ccc; padding: 10px; margin-bottom: 20px;'>";
        
        echo "<h3>Username: " . htmlspecialchars($row['username']) . "</h3>";
        echo "<p>Email: " . htmlspecialchars($row['email']) . "</p>";
        echo "<p>NIK KTP: " . htmlspecialchars($row['nik_ktp']) . "</p>";
        echo "<p>No SIM: " . htmlspecialchars($row['no_sim']) . "</p>";
        
        // Periksa apakah file gambar ada
        if (!empty($row['ktp_image']) && file_exists($row['ktp_image'])) {
            echo "<img src='" . htmlspecialchars($row['ktp_image']) . "' alt='Foto KTP' width='200'><br>";
        } else {
            echo "<p>Foto KTP tidak tersedia.</p>";
        }

        echo "</div>";  // End div user info
    }
} else {
    echo "<p>Tidak ada pengguna yang terdaftar.</p>";
}
?>
