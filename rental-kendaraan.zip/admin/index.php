<?php
session_start();
include '../includes/db.php';

// Cek apakah user sudah login dan memiliki role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../auth/login.php");
    exit();
}

// Ambil data transaksi sewa dengan status 'pending', 'approved', atau 'rejected'
$stmt = $pdo->query("SELECT ts.id, u.username, k.jenis, ts.total_harga, ts.status 
                     FROM transaksi_sewa ts 
                     JOIN users u ON ts.user_id = u.id 
                     JOIN kendaraan k ON ts.kendaraan_id = k.id");
$transaksi = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../assets/js/scripts.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
            margin: 0;
            padding: 0;
        }

        h1, h2 {
            text-align: center;
            color: #4CAF50;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ddd;
        }

        table th {
            background-color: #4CAF50;
            color: white;
        }

        table tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        table tr:hover {
            background-color: #ddd;
        }

        a {
            text-decoration: none;
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            display: inline-block;
        }

        .btn-confirm {
            background-color: #4CAF50;
        }

        .btn-reject {
            background-color: #f44336;
        }

        .btn-confirm:hover {
            background-color: #45a049;
        }

        .btn-reject:hover {
            background-color: #e53935;
        }

        .no-transactions {
            text-align: center;
            font-size: 18px;
            color: #f44336;
        }

        .nav-links {
            text-align: center;
            margin: 20px 0;
        }

        .nav-links a {
            color: #4CAF50;
            font-weight: bold;
            text-decoration: none;
            padding: 10px;
        }

        .nav-links a:hover {
            color: #45a049;
        }
    </style>
</head>
<body>
  
</head>
<body>
    
    <div class="container">
        <h1>Admin Panel</h1>
        <h2>Transaksi Sewa</h2>
        
        <!-- Tabel untuk menampilkan transaksi sewa -->
        <table>
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Kendaraan</th>
                    <th>Total Harga</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($transaksi) > 0): ?>
                    <?php foreach ($transaksi as $t): ?>
                        <tr>
                            <td><?= htmlspecialchars($t['username']); ?></td>
                            <td><?= htmlspecialchars($t['jenis']); ?></td>
                            <td>Rp <?= number_format($t['total_harga'], 2, ',', '.'); ?></td>
                            <td><?= htmlspecialchars($t['status']); ?></td>
                            <td>
                                <?php if ($t['status'] == 'pending'): ?>
                                    <a href="konfirmasi.php?id=<?= $t['id']; ?>&status=approved" class="btn-confirm">Approve</a> | 
                                    <a href="konfirmasi.php?id=<?= $t['id']; ?>&status=rejected" class="btn-reject">Reject</a>
                                <?php elseif ($t['status'] == 'approved'): ?>
                                    <span class="btn-approved">Approved</span>
                                <?php elseif ($t['status'] == 'rejected'): ?>
                                    <span class="btn-rejected">Rejected</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="no-transactions">Tidak ada transaksi.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="nav-links">
            <a href="display.php">Lihat Pengguna</a> | 
            <a href="index.php">Dashboard</a>
            <a href="../auth/logout.php">Logout</a>
        </div>
    </div>

</body>
</html>
