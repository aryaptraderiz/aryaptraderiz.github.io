<?php
session_start();
include '../includes/db.php';

// Cek apakah user sudah login dan memiliki role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../auth/login.php");
    exit();
}

// Cek apakah ID dan status ada dalam URL
if (isset($_GET['id']) && isset($_GET['status'])) {
    $id = $_GET['id'];
    $status = $_GET['status'];

    // Validasi status agar hanya "approved" atau "rejected"
    if ($status === 'approved' || $status === 'rejected') {
        // Update status transaksi
        $stmt = $pdo->prepare("UPDATE transaksi_sewa SET status = :status WHERE id = :id");
        $stmt->execute(['status' => $status, 'id' => $id]);

        // Redirect ke halaman admin panel setelah pembaruan
        header("Location: index.php");
        exit();
    } else {
        // Jika status tidak valid, redirect ke halaman admin panel
        header("Location: index.php");
        exit();
    }
} else {
    // Jika ID atau status tidak ada, redirect ke halaman admin panel
    header("Location: index.php");
    exit();
}
?>
