<?php
session_start();
include 'includes/db.php';

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

$kendaraan_rekomendasi = [];
$dekorasi_rekomendasi = [];
$customer_message = "";

// Proses form
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $budget = (int)$_POST['budget'];
    $tema = $_POST['tema'];
    $warnaFavorit = $_POST['warna_favorit'];

    // Ambil kendaraan yang sesuai dengan budget
    $stmt = $pdo->prepare("SELECT * FROM kendaraan WHERE status = 'available' AND harga_sewa_per_hari <= :budget AND jenis = 'pengantin'");
    $stmt->execute(['budget' => $budget]);
    $kendaraan_rekomendasi = $stmt->fetchAll();

    // Ambil dekorasi yang tersedia berdasarkan tema atau warna favorit
    $stmtDekorasi = $pdo->prepare("SELECT * FROM dekorasi WHERE status = 'available' AND (tema = :tema OR warna_dominan = :warna)");
    $stmtDekorasi->execute(['tema' => $tema, 'warna' => $warnaFavorit]);
    $dekorasi_rekomendasi = $stmtDekorasi->fetchAll();

    // Tentukan pesan untuk pelanggan berdasarkan hasil query
    if (empty($kendaraan_rekomendasi)) {
        $customer_message = "Maaf, tidak ada mobil pengantin yang sesuai dengan budget Anda.";
    } elseif (empty($dekorasi_rekomendasi)) {
        $customer_message = "Mobil tersedia, namun dekorasi tidak sesuai dengan tema atau warna favorit Anda.";
    } else {
        $customer_message = "Berikut adalah rekomendasi mobil dan dekorasi terbaik untuk pernikahan Anda!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekomendasi Mobil Pengantin</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <header>
        <h1>Rekomendasi Mobil Pengantin</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="rekomendasi.php">Rekomendasi</a></li>
                <li><a href="transaksi_sewa.php">Dashboard</a></li>
                <li><a href="auth/logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Cari Mobil dan Dekorasi untuk Pernikahan</h2>
        <form method="POST" action="rekomendasi.php">
            <label for="budget">Masukkan Budget Anda (Rp):</label>
            <input type="number" name="budget" id="budget" min="100000" required>

            <label for="tema">Tema Pernikahan:</label>
            <select name="tema" id="tema" required>
                <option value="klasik">Klasik</option>
                <option value="modern">Modern</option>
                <option value="tradisional">Tradisional</option>
                <option value="minimalis">Minimalis</option>
            </select>

            <label for="warna_favorit">Warna Favorit untuk Dekorasi:</label>
            <input type="text" name="warna_favorit" id="warna_favorit" placeholder="Misal: putih, emas" required>

            <button type="submit">Cari Rekomendasi</button>
        </form>

        <h3><?= htmlspecialchars($customer_message); ?></h3>

        <?php if (!empty($kendaraan_rekomendasi)): ?>
            <h3>Rekomendasi Mobil:</h3>
            <form method="POST" action="proses_sewa.php">
                <div class="rekomendasi-list">
                    <?php foreach ($kendaraan_rekomendasi as $kendaraan): ?>
                        <div class="kendaraan-item">
                            <img src="assets/images/<?= htmlspecialchars($kendaraan['gambar']); ?>" alt="<?= htmlspecialchars($kendaraan['jenis']); ?>" class="kendaraan-image">
                            <p><strong>Jenis Mobil:</strong> <?= htmlspecialchars($kendaraan['jenis']); ?></p>
                            <p><strong>Harga Sewa per Hari:</strong> Rp <?= number_format($kendaraan['harga_sewa_per_hari'], 2, ',', '.'); ?></p>
                            <label>
                                <input type="radio" name="kendaraan_id" value="<?= $kendaraan['id']; ?>" required>
                                Pilih Mobil Ini
                            </label>
                        </div>
                    <?php endforeach; ?>
                </div>
        <?php endif; ?>

        <?php if (!empty($dekorasi_rekomendasi)): ?>
            <h3>Rekomendasi Dekorasi:</h3>
            <div class="rekomendasi-list">
                <?php foreach ($dekorasi_rekomendasi as $dekorasi): ?>
                    <div class="dekorasi-item">
                        <img src="assets/images/<?= htmlspecialchars($dekorasi['gambar']); ?>" alt="<?= htmlspecialchars($dekorasi['nama']); ?>" class="dekorasi-image">
                        <p><strong>Nama Dekorasi:</strong> <?= htmlspecialchars($dekorasi['nama']); ?></p>
                        <p><strong>Harga Dekorasi:</strong> Rp <?= number_format($dekorasi['harga'], 2, ',', '.'); ?></p>
                        <label>
                            <input type="radio" name="dekorasi_id" value="<?= $dekorasi['id']; ?>" required>
                            Pilih Dekorasi Ini
                        </label>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($kendaraan_rekomendasi) || !empty($dekorasi_rekomendasi)): ?>
            <button type="submit">Konfirmasi Pilihan</button>
            </form>
        <?php endif; ?>
    </main>

    <footer>
        <p>&copy; 2024 Indo Rentals By Arya.</p>
    </footer>
</body>
</html>
