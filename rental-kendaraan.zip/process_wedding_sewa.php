<?php
session_start();
include 'includes/db.php';

// Cek apakah pengguna login
if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari form
    $kendaraan_id = $_POST['kendaraan_id'] ?? null;
    $wedding_date = $_POST['wedding_date'] ?? null;
    $event_type = $_POST['event_type'] ?? null;
    $bride_name = $_POST['bride_name'] ?? null;
    $groom_name = $_POST['groom_name'] ?? null;
    $contact_email = $_POST['contact_email'] ?? null;
    $celebration_address = $_POST['celebration_address'] ?? null;
    $decoration = $_POST['decoration'] ?? null;
    $user_id = $_SESSION['user_id'];

    // Validasi input
    if (!$kendaraan_id || !$wedding_date || !$event_type || !$bride_name || !$groom_name || !$contact_email || !$celebration_address) {
        die("Semua field wajib diisi.");
    }

    if (!filter_var($contact_email, FILTER_VALIDATE_EMAIL)) {
        die("Email tidak valid.");
    }

    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $wedding_date)) {
        die("Format tanggal pernikahan tidak valid.");
    }

    try {
        // Simpan data ke tabel transaksi_sewa
        $query = "INSERT INTO transaksi_sewa (
                    kendaraan_id, wedding_date, event_type, bride_name, groom_name, contact_email, celebration_address, decoration, user_id, status
                  ) VALUES (
                    :kendaraan_id, :wedding_date, :event_type, :bride_name, :groom_name, :contact_email, :celebration_address, :decoration, :user_id, 'pending'
                  )";
        $stmt = $pdo->prepare($query);

        // Bind parameter
        $stmt->bindParam(':kendaraan_id', $kendaraan_id, PDO::PARAM_INT);
        $stmt->bindParam(':wedding_date', $wedding_date, PDO::PARAM_STR);
        $stmt->bindParam(':event_type', $event_type, PDO::PARAM_STR);
        $stmt->bindParam(':bride_name', $bride_name, PDO::PARAM_STR);
        $stmt->bindParam(':groom_name', $groom_name, PDO::PARAM_STR);
        $stmt->bindParam(':contact_email', $contact_email, PDO::PARAM_STR);
        $stmt->bindParam(':celebration_address', $celebration_address, PDO::PARAM_STR);
        $stmt->bindParam(':decoration', $decoration, PDO::PARAM_STR);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);

        // Eksekusi query
        if ($stmt->execute()) {
            $sewa_id = $pdo->lastInsertId();
            header("Location: form_pembayaran.php?sewa_id=$sewa_id");
            exit();
        } else {
            throw new Exception("Gagal menyimpan data sewa.");
        }
    } catch (Exception $e) {
        die("Terjadi kesalahan: " . $e->getMessage());
    }
}
?>
