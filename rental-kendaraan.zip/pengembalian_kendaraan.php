<?php
session_start();
include 'includes/db.php';

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

// Ambil daftar transaksi yang statusnya approved dan belum dikembalikan
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("
    SELECT ts.id, k.jenis, ts.jumlah_hari, ts.total_harga, ts.tanggal_sewa, ts.status
    FROM transaksi_sewa ts
    JOIN kendaraan k ON ts.kendaraan_id = k.id
    WHERE ts.user_id = ? AND ts.status = 'approved' AND ts.tanggal_kembali IS NULL
");
$stmt->execute([$user_id]);
$transaksi = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/styles.css">

    <title>Pengembalian Kendaraan</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <header>
        <h1>Pengembalian Kendaraan</h1>
        <p>Selamat datang kembali, <?= htmlspecialchars($_SESSION['username']); ?>!</p>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="transaksi_sewa.php">Dashboard</a></li>
                <li><a href="auth/logout.php">Logout</a></li>
                <li><a href="faq.php">FAQ</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Daftar Kendaraan yang Dapat Dikembalikan</h2>
        <table>
            <thead>
                <tr>
                    <th>ID Transaksi</th>
                    <th>Jenis Kendaraan</th>
                    <th>Jumlah Hari</th>
                    <th>Total Harga</th>
                    <th>Tanggal Sewa</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($transaksi) > 0): ?>
                    <?php foreach ($transaksi as $row): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['id']); ?></td>
                            <td><?= htmlspecialchars($row['jenis']); ?></td>
                            <td><?= htmlspecialchars($row['jumlah_hari']); ?></td>
                            <td>Rp <?= number_format($row['total_harga'], 2, ',', '.'); ?></td>
                            <td><?= htmlspecialchars($row['tanggal_sewa']); ?></td>
                            <td><?= htmlspecialchars($row['status']); ?></td>
                            <td>
                                <a href="proses_pengembalian.php?id=<?= $row['id']; ?>" class="btn-kembalikan">Kembalikan</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7">Tidak ada kendaraan yang dapat dikembalikan saat ini.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </main>

    <footer>
        <p>&copy; 2024 Indo Rentals</p>
    </footer>
</body>
</html>
