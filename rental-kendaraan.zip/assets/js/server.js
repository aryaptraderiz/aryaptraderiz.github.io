// server.js (Backend)

const express = require('express');
const app = express();
const path = require('path');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const session = require('express-session');

// Database connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'password', // Update this with your own database credentials
  database: 'rental_db'
});

// Connect to the database
db.connect((err) => {
  if (err) throw err;
  console.log('Connected to database!');
});

// Middleware
app.use(express.static('public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: true
}));

// Routes
// Check if user is logged in
app.get('/dashboard', (req, res) => {
  if (!req.session.user_id) {
    return res.redirect('/login');
  }

  // Fetch available vehicles from the database
  db.query("SELECT * FROM kendaraan WHERE status = 'available'", (err, result) => {
    if (err) throw err;
    res.json(result); // Return available vehicles as JSON
  });
});

// Process the rental
app.post('/sewa', (req, res) => {
  const { kendaraan_id, jumlah_hari, total_harga } = req.body;
  const user_id = req.session.user_id;

  const query = 'INSERT INTO transaksi (user_id, kendaraan_id, jumlah_hari, total_harga) VALUES (?, ?, ?, ?)';
  db.query(query, [user_id, kendaraan_id, jumlah_hari, total_harga], (err, result) => {
    if (err) throw err;
    res.send({ message: 'Sewa berhasil!', transaksi_id: result.insertId });
  });
});

// Start the server
app.listen(3000, () => {
  console.log('Server running on http://localhost:3000');
});
