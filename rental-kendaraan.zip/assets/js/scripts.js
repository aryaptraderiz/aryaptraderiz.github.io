// Untuk menghandle tombol sewa kendaraan
$(document).on('click', '.sewa', function() {
    var kendaraan_id = $(this).data('id');
    var durasi = prompt("Masukkan durasi sewa dalam hari:");

    if (durasi && !isNaN(durasi) && durasi > 0) {
        // Mengirim data menggunakan AJAX untuk memesan kendaraan
        $.ajax({
            url: 'sewa.php', // URL untuk pemrosesan pemesanan kendaraan
            method: 'POST',
            data: {
                kendaraan_id: kendaraan_id,
                durasi: durasi
            },
            success: function(response) {
                alert(response); // Tampilkan pesan jika berhasil
                location.reload(); // Memuat ulang halaman setelah pemesanan berhasil
            },
            error: function() {
                alert('Terjadi kesalahan. Silakan coba lagi.');
            }
        });
    } else {
        alert("Durasi sewa tidak valid.");
    }
});

// Untuk memperbarui status pembayaran (Konfirmasi dan Tolak)
$(document).on('click', '.konfirmasi', function() {
    var pembayaran_id = $(this).data('id');
    var status = 'confirmed'; // Set status menjadi confirmed

    // Kirim data menggunakan AJAX untuk mengonfirmasi pembayaran
    $.ajax({
        url: 'admin/konfirmasi.php', // URL untuk pemrosesan konfirmasi pembayaran
        method: 'GET',
        data: {
            id: pembayaran_id,
            status: status
        },
        success: function(response) {
            alert(response); // Tampilkan pesan setelah berhasil mengonfirmasi
            location.reload(); // Memuat ulang halaman untuk memperbarui status
        },
        error: function() {
            alert('Terjadi kesalahan. Silakan coba lagi.');
        }
    });
});

$(document).on('click', '.tolak', function() {
    var pembayaran_id = $(this).data('id');
    var status = 'rejected'; // Set status menjadi rejected

    // Kirim data menggunakan AJAX untuk menolak pembayaran
    $.ajax({
        url: 'admin/konfirmasi.php', // URL untuk pemrosesan menolak pembayaran
        method: 'GET',
        data: {
            id: pembayaran_id,
            status: status
        },
        success: function(response) {
            alert(response); // Tampilkan pesan setelah berhasil menolak
            location.reload(); // Memuat ulang halaman untuk memperbarui status
        },
        error: function() {
            alert('Terjadi kesalahan. Silakan coba lagi.');
        }
    });
});
