<?php
session_start();
include 'includes/db.php';

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

// Cek apakah ID transaksi diberikan
if (isset($_GET['id'])) {
    $transaksi_id = $_GET['id'];
    
    // Periksa apakah transaksi ini milik pengguna yang login
    $stmt = $pdo->prepare("SELECT * FROM transaksi_sewa WHERE id = :id AND user_id = :user_id");
    $stmt->execute(['id' => $transaksi_id, 'user_id' => $_SESSION['user_id']]);
    $transaksi = $stmt->fetch();

    // Pastikan transaksi ditemukan dan statusnya 'approved'
    if ($transaksi && $transaksi['status'] == 'approved' && $transaksi['tanggal_kembali'] === NULL) {
        // Proses pengembalian kendaraan (mengupdate status dan tanggal kembali)
        $tanggal_kembali = date('Y-m-d');  // Tanggal hari ini
        
        $update_stmt = $pdo->prepare("UPDATE transaksi_sewa SET status = 'returned', tanggal_kembali = :tanggal_kembali WHERE id = :id");
        $update_stmt->execute(['tanggal_kembali' => $tanggal_kembali, 'id' => $transaksi_id]);

        // Redirect ke halaman pengembalian setelah berhasil
        header("Location: pengembalian_kendaraan.php");
        exit();
    } else {
        echo "Transaksi tidak ditemukan atau status tidak sesuai untuk pengembalian.";
    }
} else {
    echo "ID transaksi tidak diberikan.";
}
