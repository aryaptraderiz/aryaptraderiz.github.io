<?php
session_start();
include 'includes/db.php';

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

// Ambil daftar kendaraan yang tersedia
$stmt = $pdo->query("SELECT * FROM kendaraan WHERE status = 'available'");
$kendaraan = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Indo Rentals</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="icon" type="image/png" href="assets/images/logo.jpg">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="assets/js/scripts.js"></script>
</head>
<body>
    <style></style>
    <header>
    <h1>Dashboard Penyewaan Kendaraan</h1>
    <p class="welcome-message">Selamat datang Di Online Cars Indo Rentals, <?= htmlspecialchars($_SESSION['username']); ?>!</p>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="sewa_pernikahan.php">Untuk Sewa Pernikahan</a></li>
            <li><a href="transaksi_sewa.php">Dashboard</a></li>
            <li><a href="pengembalian_kendaraan.php">Pengembalian Kendaraan</a></li>
            <li><a href="auth/logout.php">Logout</a></li>
        </ul>
    </nav>
    </header>

    <main>
        <h2>Available Cars</h2>

        <!-- Daftar kendaraan yang tersedia -->
        <div class="kendaraan-list">
            <?php if (count($kendaraan) > 0): ?>
                <?php foreach ($kendaraan as $kendaraan_item): ?>
                    <div class="kendaraan-item">
                        <!-- Menampilkan gambar kendaraan -->
                        <img src="assets/images/<?= htmlspecialchars($kendaraan_item['gambar']); ?>" alt="<?= htmlspecialchars($kendaraan_item['jenis']); ?>" class="kendaraan-image">
                        
                        <p><strong>Jenis Kendaraan:</strong> <?= htmlspecialchars($kendaraan_item['jenis']); ?></p>
                        <p><strong>Plat Nomor:</strong> <?= htmlspecialchars($kendaraan_item['plat_no']); ?></p>
                        <p><strong>Harga Per Hari:</strong> Rp <?= number_format($kendaraan_item['harga_sewa_per_hari'], 2, ',', '.'); ?></p>
                        
                        <!-- Tombol Sewa -->
                        <button class="sewa" data-id="<?= $kendaraan_item['id']; ?>" data-harga="<?= $kendaraan_item['harga_sewa_per_hari']; ?>" data-jenis="<?= htmlspecialchars($kendaraan_item['jenis']); ?>">Sewa</button>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Tidak ada kendaraan yang tersedia saat ini.</p>
            <?php endif; ?>
        </div>
    </main>

    <footer>
        <p>&copy; 2024 Indo Rentals By Arya.</p>
    </footer>

    <!-- Modal untuk perhitungan sewa -->
    <div id="modal-sewa" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Perhitungan Sewa</h2>
            <p><strong>Jenis Kendaraan:</strong> <span id="modal-jenis"></span></p>
            <p><strong>Harga per Hari:</strong> Rp <span id="modal-harga"></span></p>
            <label for="jumlah-hari">Jumlah Hari:</label>
            <input type="number" id="jumlah-hari" min="1" value="1">
            <p><strong>Total Harga:</strong> Rp <span id="modal-total-harga">0</span></p>
            <button id="konfirmasi-sewa">Konfirmasi Sewa</button>
        </div>
    </div>

    <script>
        $(document).on('click', '.sewa', function() {
    var hargaPerHari = $(this).data('harga');
    var jenisKendaraan = $(this).data('jenis');
    var kendaraanId = $(this).data('id'); // Ambil ID kendaraan dari tombol yang diklik
    
    // Mengisi data di modal
    $('#modal-jenis').text(jenisKendaraan);
    $('#modal-harga').text(hargaPerHari.toLocaleString('id-ID', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
    $('#jumlah-hari').val(1); // Reset input
    $('#modal-total-harga').text(hargaPerHari.toLocaleString('id-ID', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));

    // Simpan ID kendaraan ke modal
    $('#modal-sewa').data('kendaraan-id', kendaraanId); // Menyimpan ID kendaraan di modal

    // Tampilkan modal
    $('#modal-sewa').show();
});


        // Menutup modal
        $('.close').on('click', function() {
            $('#modal-sewa').hide();
        });

        // Menghitung total harga berdasarkan jumlah hari
        $('#jumlah-hari').on('input', function() {
            var hargaPerHari = $('#modal-harga').text().replace('Rp ', '').replace(',', '');
            var jumlahHari = $(this).val();
            var totalHarga = hargaPerHari * jumlahHari;
            $('#modal-total-harga').text(totalHarga.toLocaleString('id-ID', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
        });

  // Konfirmasi Sewa dan kirim data ke server
$('#konfirmasi-sewa').on('click', function() {
    var jumlahHari = $('#jumlah-hari').val();
    var hargaPerHari = $('#modal-harga').text().replace('Rp ', '').replace(',', '');
    var kendaraanId = $('#modal-sewa').data('kendaraan-id'); // Ambil ID kendaraan dari modal yang telah di-set sebelumnya
    var totalHarga = hargaPerHari * jumlahHari;
    
    // Mengirim data ke server melalui AJAX
    $.ajax({
        url: 'proses_sewa.php',
        type: 'POST',
        data: {
            kendaraan_id: kendaraanId,
            jumlah_hari: jumlahHari,
            total_harga: totalHarga
        },
        success: function(response) {
            alert('Sewa berhasil! ID Transaksi: ' + response);
            $('#modal-sewa').hide();
        },
        error: function() {
            alert('Gagal melakukan transaksi.');
        }
    });
});

    </script>
</body>
</html>
