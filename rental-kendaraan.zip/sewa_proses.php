<?php
session_start();
include 'includes/db.php';

// Cek jika pengguna belum login
if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

// Ambil data yang dikirim dari form
$kendaraan_id = $_POST['kendaraan_id'];
$jumlah_hari = $_POST['jumlah_hari'];

// Ambil data kendaraan berdasarkan ID
$stmt = $pdo->prepare("SELECT * FROM kendaraan WHERE id = ?");
$stmt->execute([$kendaraan_id]);
$kendaraan = $stmt->fetch();

// Hitung total harga
$total_harga = $kendaraan['harga_sewa_per_hari'] * $jumlah_hari;

// Simpan transaksi sewa ke database
$stmt = $pdo->prepare("INSERT INTO transaksi_sewa (user_id, kendaraan_id, jumlah_hari, total_harga, status) VALUES (?, ?, ?, ?, ?)");
$stmt->execute([$_SESSION['user_id'], $kendaraan_id, $jumlah_hari, $total_harga, 'pending']); // Status bisa 'pending', 'confirmed', dll.

// Redirect ke halaman konfirmasi atau status transaksi
header("Location: sewa_konfirmasi.php?id=" . $pdo->lastInsertId());
exit();
?>
