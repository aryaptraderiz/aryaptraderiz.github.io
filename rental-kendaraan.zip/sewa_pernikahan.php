<?php
session_start();
include 'includes/db.php';

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

// Cek jika form budget disubmit
$budget_min = isset($_POST['budget_min']) ? $_POST['budget_min'] : 0;
$budget_max = isset($_POST['budget_max']) ? $_POST['budget_max'] : 0;

// Ambil daftar kendaraan yang sesuai dengan budget
$query = "SELECT * FROM kendaraan WHERE status = 'available'";

// Jika budget di set, tambahkan filter harga
if ($budget_min > 0 && $budget_max > 0) {
    $query .= " AND harga_sewa_per_hari BETWEEN :budget_min AND :budget_max";
}

$stmt = $pdo->prepare($query);

// Bind parameter jika budget diberikan
if ($budget_min > 0 && $budget_max > 0) {
    $stmt->bindParam(':budget_min', $budget_min, PDO::PARAM_INT);
    $stmt->bindParam(':budget_max', $budget_max, PDO::PARAM_INT);
}

$stmt->execute();
$kendaraan = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Indo Rentals</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="icon" type="image/png" href="assets/images/logo.jpg">
    <style>
          body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: white;
            padding: 10px 0;
            text-align: center;
        }

        header nav ul {
            list-style: none;
            padding: 0;
        }

        header nav ul li {
            display: inline;
            margin-right: 20px;
        }

        header nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        main {
            padding: 20px;
        }

        h2 {
            color: #333;
            text-align: center;
        }

        .form-container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .form-container input, .form-container textarea, .form-container select {
            width: 100%;
            padding: 10px;
            margin: 10px 0 20px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 16px;
        }

        .form-container textarea {
            height: 150px;
        }

        .form-container button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        .form-container button:hover {
            background-color: #45a049;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
            padding-top: 60px;
        }

        .modal-content {
    background-color: #fff;
    margin: 5% auto;
    padding: 20px;
    border-radius: 8px;
    width: 80%;
    max-width: 600px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.modal .close {
    color: #aaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
    cursor: pointer;
}

.modal .close:hover,
.modal .close:focus {
    color: black;
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    font-size: 16px;
    color: #333;
}

.form-group input,
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 12px;
    font-size: 16px;
    border: 1px solid #ddd;
    border-radius: 4px;
    margin-top: 6px;
}

.form-group textarea {
    height: 150px;
    resize: vertical;
}

.button-group {
    display: flex;
    justify-content: space-between;
    margin-top: 20px;
}

.submit-btn,
.close-btn {
    background-color: #4CAF50;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s ease;
}

.submit-btn:hover {
    background-color: #45a049;
}

.close-btn {
    background-color: #f44336;
}

.close-btn:hover {
    background-color: #e53935;
}

    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <header>
        <h1>Dashboard Penyewaan Kendaraan</h1>
        <p class="welcome-message">Selamat datang Di Online Cars Indo Rentals, <?= htmlspecialchars($_SESSION['username']); ?>!</p>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="sewa_pernikahan.php">Sewa Pernikahan</a></li>
                <li><a href="transaksi_sewa.php">Dashboard</a></li>
                <li><a href="pengembalian_kendaraan.php">Pengembalian Kendaraan</a></li>
                <li><a href="auth/logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Filter Kendaraan Berdasarkan Budget</h2>
        <form method="POST">
            <div class="form-container">
                <label for="budget_min">Budget Minimum (Rp):</label>
                <input type="number" id="budget_min" name="budget_min" value="<?= htmlspecialchars($budget_min); ?>" required>
                
                <label for="budget_max">Budget Maksimum (Rp):</label>
                <input type="number" id="budget_max" name="budget_max" value="<?= htmlspecialchars($budget_max); ?>" required>
                
                <button type="submit">Cari Kendaraan</button>
            </div>
        </form>

        <h2>Kendaraan Tersedia</h2>
        <div class="kendaraan-list">
            <?php if (count($kendaraan) > 0): ?>
                <?php foreach ($kendaraan as $kendaraan_item): ?>
                    <div class="kendaraan-item">
                        <img src="assets/images/<?= htmlspecialchars($kendaraan_item['gambar']); ?>" alt="<?= htmlspecialchars($kendaraan_item['jenis']); ?>" class="kendaraan-image">
                        
                        <p><strong>Jenis Kendaraan:</strong> <?= htmlspecialchars($kendaraan_item['jenis']); ?></p>
                        <p><strong>Plat Nomor:</strong> <?= htmlspecialchars($kendaraan_item['plat_no']); ?></p>
                        <p><strong>Harga Per Hari:</strong> Rp <?= number_format($kendaraan_item['harga_sewa_per_hari'], 2, ',', '.'); ?></p>
                        
                        <button class="sewa" data-id="<?= $kendaraan_item['id']; ?>" data-harga="<?= $kendaraan_item['harga_sewa_per_hari']; ?>" data-jenis="<?= htmlspecialchars($kendaraan_item['jenis']); ?>">Sewa</button>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Tidak ada kendaraan yang tersedia sesuai budget Anda.</p>
            <?php endif; ?>
        </div>
    </main>

    <footer>
        <p>&copy; 2024 Indo Rentals By Arya.</p>
    </footer>

    <!-- Modal untuk perhitungan sewa dan detail pernikahan -->
    <div id="modal-sewa" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Detail Sewa Kendaraan untuk Pernikahan</h2>

            <form id="wedding-form" action="process_wedding_sewa.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="kendaraan_id" id="kendaraan-id">

                <div class="form-group">
                    <label for="wedding_date">Tanggal Pernikahan:</label>
                    <input type="date" id="wedding_date" name="wedding_date" required>
                </div>

                <div class="form-group">
                    <label for="event_type">Jenis Acara:</label>
                    <select id="event_type" name="event_type" required>
                        <option value="akad nikah">Akad Nikah</option>
                        <option value="resepsi">Resepsi</option>
                        <option value="pesta">Pesta</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="bride_name">Nama Pengantin Wanita:</label>
                    <input type="text" id="bride_name" name="bride_name" placeholder="Nama Pengantin Wanita" required>
                </div>

                <div class="form-group">
                    <label for="groom_name">Nama Pengantin Pria:</label>
                    <input type="text" id="groom_name" name="groom_name" placeholder="Nama Pengantin Pria" required>
                </div>

                <div class="form-group">
                    <label for="contact_email">Email:</label>
                    <input type="email" id="contact_email" name="contact_email" placeholder="Email Pengantin" required>
                </div>

                <div class="form-group">
                    <label for="celebration_address">Alamat:</label>
                    <textarea id="celebration_address" name="celebration_address" placeholder="Alamat Tempat Perayaan" rows="4" required></textarea>
                </div>

                <div class="form-group">
                    <label for="decoration">Dekorasi Tambahan:</label>
                    <select id="decoration" name="decoration" class="form-control">
                        <option value="0">Tidak Ada Dekorasi</option>
                        <option value="bunga">Bunga</option>
                        <option value="balon">Balon</option>
                        <option value="lampu">Lampu</option>
                        <option value="karpet">Karpet</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="sewa_days">Jumlah Hari Sewa:</label>
                    <input type="number" id="sewa_days" name="sewa_days" value="1" min="1" required>
                </div>

                <div class="form-group">
                    <label for="total_cost">Total Biaya Sewa (Rp):</label>
                    <input type="number" id="total_cost" name="total_cost" value="0" readonly>
                </div>

                <div class="button-group">
                    <button type="submit" class="submit-btn">Kirim Detail Sewa</button>
                    <button type="button" class="close-btn">Tutup</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        $(document).on('click', '.sewa', function() {
            var kendaraanId = $(this).data('id');
            var hargaPerHari = $(this).data('harga');

            // Set the kendaraan ID and price per day in the modal form
            $('#kendaraan-id').val(kendaraanId);

            // Calculate the total cost when the number of days is changed
            $('#sewa_days').on('input', function() {
                var days = $(this).val();
                var totalCost = hargaPerHari * days;
                $('#total_cost').val(totalCost);
            });

            // Calculate decoration cost when selection is changed
            $('#decoration').on('change', function() {
                var decoration = $(this).val();
                var decorationCost = 0;
                switch(decoration) {
                    case 'bunga':
                        decorationCost = 500000; // Add cost for bunga
                        break;
                    case 'balon':
                        decorationCost = 200000; // Add cost for balon
                        break;
                    case 'lampu':
                        decorationCost = 300000; // Add cost for lampu
                        break;
                    case 'karpet':
                        decorationCost = 100000; // Add cost for karpet
                        break;
                }
                var days = $('#sewa_days').val();
                var totalCost = (hargaPerHari * days) + decorationCost;
                $('#total_cost').val(totalCost);
            });

            // Show the modal
            $('#modal-sewa').show();
        });

        // Close the modal when the close icon is clicked
        $('.close').on('click', function() {
            $('#modal-sewa').hide();
        });

        // Close the modal when the close button is clicked
        $('.close-btn').on('click', function() {
            $('#modal-sewa').hide();
        });
    </script>
</body>
</html>
