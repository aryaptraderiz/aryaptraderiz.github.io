<?php
session_start();
include '../includes/db.php';

// Cek apakah admin sudah login
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../auth/login.php");
    exit();
}

// Ambil ID transaksi dan status dari URL
$id = $_GET['id'];
$status = $_GET['status'];

// Periksa apakah status valid
if ($status != 'confirmed' && $status != 'rejected') {
    echo "Status tidak valid.";
    exit();
}

// Update status transaksi
$stmt = $pdo->prepare("UPDATE pembayaran SET status = ? WHERE id = ?");
if ($stmt->execute([$status, $id])) {
    echo "Transaksi berhasil diperbarui ke status '$status'.";
    header("Location: pembayaran_pending.php"); // Redirect kembali ke halaman pembayaran pending
    exit();
} else {
    echo "Terjadi kesalahan saat memperbarui status transaksi.";
}
?>
