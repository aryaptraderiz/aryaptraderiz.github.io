<?php
session_start();
include 'includes/db.php';

// Cek apakah pengguna login
if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

// Ambil ID sewa dari URL
if (!isset($_GET['sewa_id'])) {
    echo "ID Sewa tidak ditemukan.";
    exit();
}

$sewa_id = $_GET['sewa_id'];

// Ambil detail pembayaran menggunakan ID sewa
$query = $pdo->prepare("SELECT p.*, ts.total_biaya, ts.tanggal_sewa, ts.wedding_date, k.jenis
                        FROM pembayaran p
                        JOIN transaksi_sewa ts ON p.transaksi_sewa_id = ts.id
                        JOIN kendaraan k ON ts.kendaraan_id = k.id
                        WHERE p.transaksi_sewa_id = :sewa_id");

$query->bindParam(':sewa_id', $sewa_id, PDO::PARAM_INT);
$query->execute();
$pembayaran = $query->fetch();

if (!$pembayaran) {
    echo "Data pembayaran tidak ditemukan.";
    exit();
}

// Tampilkan status pembayaran
$status = $pembayaran['status']; // Status pembayaran: 'pending', 'confirmed', 'failed'
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Status Pembayaran</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fc;
            color: #333;
            padding: 20px;
        }

        main {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h2 {
            font-size: 24px;
            color: #2d3a3f;
            text-align: center;
            margin-bottom: 20px;
        }

        .status-container {
            text-align: center;
            font-size: 18px;
            margin-top: 20px;
        }

        .status-container p {
            font-weight: bold;
            color: #2d3a3f;
        }

        .status-container .status-pending {
            color: orange;
        }

        .status-container .status-confirmed {
            color: green;
        }

        .status-container .status-failed {
            color: red;
        }

        .details {
            margin-top: 30px;
            font-size: 16px;
        }

        .details p {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <main>
        <h2>Status Pembayaran</h2>
        
        <div class="status-container">
            <p>Status Pembayaran:</p>
            <?php if ($status === 'pending'): ?>
                <p class="status-pending">Menunggu Konfirmasi</p>
            <?php elseif ($status === 'confirmed'): ?>
                <p class="status-confirmed">Pembayaran Dikonfirmasi</p>
            <?php elseif ($status === 'failed'): ?>
                <p class="status-failed">Pembayaran Gagal</p>
            <?php else: ?>
                <p>Status tidak diketahui.</p>
            <?php endif; ?>
        </div>

        <div class="details">
            <p><strong>Detail Sewa:</strong></p>
            <p>Jenis Kendaraan: <?= htmlspecialchars($pembayaran['jenis']); ?></p>
            <p>Tanggal Sewa: <?= htmlspecialchars($pembayaran['tanggal_sewa']); ?></p>
            <p>Tanggal Pernikahan: <?= htmlspecialchars($pembayaran['wedding_date']); ?></p>
            <p><strong>Total Biaya Sewa: Rp <?= number_format($pembayaran['total_biaya'], 2, ',', '.'); ?></strong></p>
            <p><strong>Metode Pembayaran: </strong><?= htmlspecialchars($pembayaran['metode_pembayaran']); ?></p>
        </div>
    </main>
</body>
</html>
