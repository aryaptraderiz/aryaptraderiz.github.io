<?php
session_start();
include 'includes/db.php';

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'User not logged in']);
    exit();
}

// Ambil data dari request POST
$kendaraan_id = $_POST['kendaraan_id'];
$jumlah_hari = $_POST['jumlah_hari'];
$total_harga = $_POST['total_harga'];
$user_id = $_SESSION['user_id']; // ID pengguna yang sedang login

// Validasi input
if (empty($kendaraan_id) || empty($jumlah_hari) || empty($total_harga)) {
    echo json_encode(['error' => 'Missing required fields']);
    exit();
}

// Insert data transaksi ke dalam tabel transaksi_sewa
$stmt = $pdo->prepare("INSERT INTO transaksi_sewa (user_id, kendaraan_id, jumlah_hari, total_harga) VALUES (?, ?, ?, ?)");
$stmt->execute([$user_id, $kendaraan_id, $jumlah_hari, $total_harga]);

// Mengembalikan ID transaksi yang baru saja disimpan
$transaksi_id = $pdo->lastInsertId();
echo json_encode($transaksi_id);
?>
