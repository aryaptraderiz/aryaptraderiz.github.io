<?php
session_start();
include 'includes/db.php';

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

// Ambil daftar transaksi pengguna
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("
    SELECT ts.id, k.jenis, ts.jumlah_hari, ts.total_harga, ts.tanggal_sewa, ts.status
    FROM transaksi_sewa ts
    JOIN kendaraan k ON ts.kendaraan_id = k.id
    WHERE ts.user_id = ?
");
$stmt->execute([$user_id]);
$transaksi = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Transaksi</title>
    <style>
        /* Menata umum tampilan halaman */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        /* Header */
        header {
            background-color: #4CAF50;
            color: white;
            padding: 20px 0;
            text-align: center;
        }

        header h1 {
            margin: 0;
        }

        header nav ul {
            list-style: none;
            padding: 0;
        }

        header nav ul li {
            display: inline;
            margin-right: 20px;
        }

        header nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        header nav ul li a:hover {
            text-decoration: underline;
        }

        /* Main section */
        main {
            padding: 20px;
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
        }

        /* Tabel transaksi */
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
            margin-top: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        td {
            background-color: #f9f9f9;
        }

        tr:nth-child(even) td {
            background-color: #f1f1f1;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        table td[colspan="6"] {
            text-align: center;
            font-style: italic;
        }

        /* Footer */
        footer {
            background-color: #333;
            color: white;
            padding: 10px 0;
            text-align: center;
        }

        /* Responsif */
        @media screen and (max-width: 768px) {
            table {
                font-size: 14px;
            }

            th, td {
                padding: 8px 10px;
            }

            header nav ul li {
                display: block;
                margin-bottom: 10px;
            }

            header nav ul li a {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>Riwayat Transaksi</h1>
        <p>Selamat datang kembali, <?= htmlspecialchars($_SESSION['username']); ?>!</p>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="auth/logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Daftar Transaksi</h2>
        <table>
            <thead>
                <tr>
                    <th>ID Transaksi</th>
                    <th>Jenis Kendaraan</th>
                    <th>Jumlah Hari</th>
                    <th>Total Harga</th>
                    <th>Tanggal Sewa</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($transaksi) > 0): ?>
                    <?php foreach ($transaksi as $row): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['id']); ?></td>
                            <td><?= htmlspecialchars($row['jenis']); ?></td>
                            <td><?= htmlspecialchars($row['jumlah_hari']); ?></td>
                            <td>Rp <?= number_format($row['total_harga'], 2, ',', '.'); ?></td>
                            <td><?= htmlspecialchars($row['tanggal_sewa']); ?></td>
                            <td><?= htmlspecialchars($row['status']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6">Tidak ada transaksi ditemukan.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </main>

    <footer>
        <p>&copy; 2024 Indo Rentals</p>
    </footer>
</body>
</html>
