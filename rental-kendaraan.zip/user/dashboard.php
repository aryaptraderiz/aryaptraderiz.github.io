<?php
session_start();
include 'includes/db.php';

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

// Ambil daftar transaksi pengguna
$user_id = $_SESSION['user_id'];

// Query untuk mengambil transaksi sewa
$stmt = $pdo->prepare("SELECT ts.id, k.jenis, ts.jumlah_hari, ts.total_harga, ts.tanggal_sewa, ts.status
                       FROM transaksi_sewa ts
                       JOIN kendaraan k ON ts.kendaraan_id = k.id
                       WHERE ts.user_id = ?");
$stmt->execute([$user_id]);

// Ambil hasil transaksi
$transaksi = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Penyewaan Kendaraan</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <header>
        <h1>Dashboard Penyewaan Kendaraan</h1>
        <p class="welcome-message">Selamat datang di Online Cars Indo Rentals, <?= htmlspecialchars($_SESSION['username']); ?>!</p>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="auth/logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Riwayat Transaksi Sewa</h2>

        <!-- Cek jika tidak ada transaksi -->
        <?php if (count($transaksi) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID Transaksi</th>
                        <th>Jenis Kendaraan</th>
                        <th>Jumlah Hari</th>
                        <th>Total Harga</th>
                        <th>Tanggal Sewa</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($transaksi as $row): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['id']); ?></td>
                            <td><?= htmlspecialchars($row['jenis']); ?></td>
                            <td><?= htmlspecialchars($row['jumlah_hari']); ?></td>
                            <td>Rp <?= number_format($row['total_harga'], 2, ',', '.'); ?></td>
                            <td><?= htmlspecialchars($row['tanggal_sewa']); ?></td>
                            <td><?= htmlspecialchars($row['status']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Anda belum memiliki riwayat transaksi sewa.</p>
        <?php endif; ?>
    </main>

    <footer>
        <p>&copy; 2024 Indo Rentals.</p>
    </footer>
</body>
</html>
