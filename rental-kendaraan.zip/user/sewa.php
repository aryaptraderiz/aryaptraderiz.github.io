<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id'])) {
    echo "Harap login terlebih dahulu.";
    exit();
}

if (isset($_POST['kendaraan_id']) && isset($_POST['durasi'])) {
    $kendaraan_id = $_POST['kendaraan_id'];
    $durasi = $_POST['durasi'];

    $stmt = $pdo->prepare("SELECT * FROM kendaraan WHERE id = :id AND status = 'available'");
    $stmt->execute(['id' => $kendaraan_id]);
    $kendaraan = $stmt->fetch();

    if ($kendaraan) {
        $total_harga = $kendaraan['harga_sewa_per_hari'] * $durasi;
        $stmt = $pdo->prepare("INSERT INTO pembayaran (user_id, kendaraan_id, tanggal_sewa, durasi, total_harga) VALUES (:user_id, :kendaraan_id, NOW(), :durasi, :total_harga)");
        $stmt->execute([
            'user_id' => $_SESSION['user_id'],
            'kendaraan_id' => $kendaraan_id,
            'durasi' => $durasi,
            'total_harga' => $total_harga
        ]);
        echo "Pemesanan berhasil. Total harga: Rp " . number_format($total_harga, 2, ',', '.');
    } else {
        echo "Kendaraan tidak tersedia.";
    }
}
?>
