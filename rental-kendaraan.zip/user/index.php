<?php
session_start();
include '../includes/db.php';

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Ambil data mobil dari database
$stmt = $pdo->prepare("SELECT * FROM cars");
$stmt->execute();
$cars = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Daftar Mobil</title>
</head>
<body>
    <h2>Selamat datang, <?php echo $_SESSION['username']; ?>!</h2>
    <h3>Daftar Mobil yang Tersedia</h3>
    
    <table border="1">
        <thead>
            <tr>
                <th>Nama Mobil</th>
                <th>Harga Sewa per Hari</th>
                <th>Nomor Plat</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($cars as $car): ?>
                <tr>
                    <td><?php echo htmlspecialchars($car['car_name']); ?></td>
                    <td><?php echo "Rp " . number_format($car['price_per_day'], 0, ',', '.'); ?></td>
                    <td><?php echo htmlspecialchars($car['plate_number']); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <p><a href="logout.php">Logout</a></p>
</body>
</html>
