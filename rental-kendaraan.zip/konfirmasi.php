<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../auth/login.php");
    exit();
}

if (isset($_GET['id']) && isset($_GET['status'])) {
    $id = $_GET['id'];
    $status = $_GET['status'];

    $stmt = $pdo->prepare("UPDATE pembayaran SET status = :status WHERE id = :id");
    $stmt->execute(['status' => $status, 'id' => $id]);

    echo "Status pembayaran berhasil diperbarui.";
}
?>
