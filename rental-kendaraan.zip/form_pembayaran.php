<?php
session_start();
include 'includes/db.php';

// Cek apakah pengguna login
if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

// Ambil ID sewa dari URL
if (!isset($_GET['sewa_id'])) {
    echo "ID Sewa tidak ditemukan.";
    exit();
}

$sewa_id = $_GET['sewa_id'];

// Ambil detail sewa dan jenis kendaraan menggunakan JOIN
$query = $pdo->prepare("SELECT ts.*, k.jenis, k.harga_sewa_per_hari, DATEDIFF(ts.wedding_date, ts.tanggal_sewa) AS lama_sewa
                        FROM transaksi_sewa ts
                        JOIN kendaraan k ON ts.kendaraan_id = k.id
                        WHERE ts.id = :sewa_id");

$query->bindParam(':sewa_id', $sewa_id, PDO::PARAM_INT);
$query->execute();
$transaksi_sewa = $query->fetch();

if (!$transaksi_sewa) {
    echo "Data sewa tidak ditemukan.";
    exit();
}

// Hitung total harga sewa
$lama_sewa = $transaksi_sewa['lama_sewa']; // Durasi sewa dalam hari
$harga_per_hari = $transaksi_sewa['harga_sewa_per_hari'];

// Pastikan harga per hari dan lama sewa valid
if ($lama_sewa > 0 && $harga_per_hari > 0) {
    $total_harga_sewa = $lama_sewa * $harga_per_hari;
} else {
    // Jika tidak valid, tampilkan pesan atau set harga default
    $total_harga_sewa = max($harga_per_hari, 1) * max($lama_sewa, 1); // Mengambil harga sewa per hari dan durasi minimal 1 hari
}

// Menangani dekorasi
$decoration_cost = 0;
$decoration = isset($transaksi_sewa['dekorasi']) ? $transaksi_sewa['dekorasi'] : null;

switch ($decoration) {
    case 'bunga':
        $decoration_cost = 500000;
        break;
    case 'balon':
        $decoration_cost = 200000;
        break;
    case 'lampu':
        $decoration_cost = 300000;
        break;
    case 'karpet':
        $decoration_cost = 100000;
        break;
}

// Hitung total biaya sewa dengan dekorasi
$total_biaya = $total_harga_sewa + $decoration_cost;

// Hitung DP (setengah dari total biaya)
$dp = $total_biaya / 2;  // DP dihitung dengan membagi total biaya (harga sewa + dekorasi) dengan 2



// Proses konfirmasi pembayaran
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $metode_pembayaran = $_POST['metode_pembayaran'];

    // Insert payment data into pembayaran table
    try {
        $query = "INSERT INTO pembayaran (transaksi_sewa_id, metode_pembayaran, total_biaya, status)
                  VALUES (:transaksi_sewa_id, :metode_pembayaran, :total_biaya, 'pending')";
        $stmt = $pdo->prepare($query);

        // Bind parameters
        $stmt->bindParam(':transaksi_sewa_id', $sewa_id, PDO::PARAM_INT);
        $stmt->bindParam(':metode_pembayaran', $metode_pembayaran, PDO::PARAM_STR);
        $stmt->bindParam(':total_biaya', $dp, PDO::PARAM_STR);  // Mengirim DP (setengah harga)

        // Execute query
        if ($stmt->execute()) {
            header("Location: payment_status.php?sewa_id=$sewa_id");
            exit();
        } else {
            echo "Gagal mengonfirmasi pembayaran.";
        }
    } catch (Exception $e) {
        echo "Terjadi kesalahan: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Pembayaran</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fc;
            color: #333;
            padding: 20px;
        }

        main {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h2 {
            font-size: 24px;
            color: #2d3a3f;
            text-align: center;
            margin-bottom: 20px;
        }

        .form-container {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        p {
            font-size: 16px;
            color: #444;
        }

        strong {
            font-weight: bold;
        }

        input[type="number"], select {
            padding: 10px;
            font-size: 16px;
            border: 2px solid #ddd;
            border-radius: 5px;
            transition: border-color 0.3s ease;
        }

        button {
            padding: 12px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <main>
        <h2>Form Pembayaran</h2>
        <form method="POST">
            <div class="form-container">
                <p><strong>Detail Sewa:</strong></p>
                <p>Jenis Kendaraan: <?= htmlspecialchars($transaksi_sewa['jenis']); ?></p>
                <p>Tanggal Sewa: <?= htmlspecialchars($transaksi_sewa['tanggal_sewa']); ?></p>
                <p>Tanggal Pernikahan: <?= htmlspecialchars($transaksi_sewa['wedding_date']); ?></p>
                
                <?php if ($decoration_cost > 0): ?>
                    <p><strong>Biaya Dekorasi (<?= htmlspecialchars($decoration) ?>): Rp <?= number_format($decoration_cost, 2, ',', '.'); ?></strong></p>
                <?php endif; ?>

                <p><strong>Total Biaya (Setengah Harga / DP): Rp <?= number_format($dp, 2, ',', '.'); ?></strong></p>


                <label for="metode_pembayaran">Metode Pembayaran:</label>
                <select id="metode_pembayaran" name="metode_pembayaran" required>
                    <option value="transfer bank">Transfer Bank</option>
                    <option value="kartu kredit">Kartu Kredit</option>
                    <option value="e-wallet">E-Wallet</option>
                </select>

                <button type="submit">Konfirmasi Pembayaran</button>
            </div>
        </form>
    </main>
</body>
</html>
